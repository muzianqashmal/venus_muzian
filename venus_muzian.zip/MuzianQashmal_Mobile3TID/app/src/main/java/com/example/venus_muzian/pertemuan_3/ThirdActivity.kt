package com.example.venus_muzian.pertemuan_3

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.example.venus_muzian.databinding.ActivityThirdBinding

class ThirdActivity : Activity() {

    private lateinit var binding: ActivityThirdBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityThirdBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnKirim.setOnClickListener {
            val noTujuan = binding.inputNoTujuan.text.toString()

            Toast.makeText(
                this,
                "Pesan berhasil dikirim ke $noTujuan",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}