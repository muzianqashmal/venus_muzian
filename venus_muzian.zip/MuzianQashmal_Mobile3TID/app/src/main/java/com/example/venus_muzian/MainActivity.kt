package com.example.venus_muzian

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.venus_muzian.pertemuan_3.ThirdActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        startActivity(
            Intent(
                this,
                ThirdActivity::class.java
            )
        )

        finish()
    }
}